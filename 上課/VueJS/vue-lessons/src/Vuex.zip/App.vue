<template>
  <div>
    <button @click="addCount">Add</button>
    <h2>{{ count }}</h2>
  </div>
</template>

<script>
export default {
  methods: {
    addCount() {
      this.$store.commit("addStoreCount");
    },
  },
  computed: {
    count() {
      return this.$store.state.count;
    },
  },
};
</script>
