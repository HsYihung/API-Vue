<template>
  <div>
    <h2>$Others</h2>
  </div>
</template>
<style scoped>
h2 {
  font: bold 30px Calibri;
  color: lightskyblue;
}
</style>
