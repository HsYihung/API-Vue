<script>
import Vue from "vue";
import VueRouter from "vue-router";

import About from "./About.vue";
import Products from "./Products.vue";

import AboutHome from "./AboutHome.vue";
import AboutUs from "./AboutUs.vue";
import AboutOtehrs from "./AboutOthers.vue";

Vue.use(VueRouter);

export default {
  router: new VueRouter({
    routes: [
      {
        path: `/about`,
        component: About,
        children: [
          { path: "", component: AboutHome },
          { path: "us", component: AboutUs },
          { path: "others", component: AboutOtehrs },
        ],
      },

      {
        path: `/Products/:sn?`,
        component: Products,
      },
    ],
  }),
};
</script>
<template>
  <div>
    <p>
      <router-link to="/about">About</router-link> |
      <router-link to="/products">Products</router-link>
    </p>
    <hr />
    <router-view></router-view>
  </div>
</template>
