<template>
  <div>
    <h2>*Home</h2>
  </div>
</template>
<style scoped>
h2 {
  font: bold 30px Calibri;
  color: lightgreen;
}
</style>
