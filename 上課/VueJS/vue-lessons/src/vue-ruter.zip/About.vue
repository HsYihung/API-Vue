<template>
  <div>
    <h1>[About]</h1>
    <br />
    <router-link to="/about/us">About us</router-link> |
    <router-link to="/about/others">About Others</router-link>

    <br />

    <p>
      <router-view></router-view>
    </p>
  </div>
</template>


<style>
h1 {
  color: darkgreen;
  font: bold 40px Comic Sans MS;
}
</style>
