<template>
  <div>
    <h1>[Products]</h1>

    <!-- <h3>{{ $route.params.sn }}</h3> -->

    <h3>{{ sn }}</h3>
  </div>
</template>

<script>
const products = {
  10: "Hat",
  20: "T-shirt",
  30: "iPad",
  40: "iPhone",
  50: "AirPods",
};

export default {
  computed: {
    sn() {
      return products[this.$route.params.sn];
    },
  },
};
</script>

<style scoped>
h1 {
  color: maroon;
  font: bold 50px Comic Sans MS;
}
</style>
